**Financial support**

* Cosanum
* Camptocamp R&D
* ACSONE R&D
