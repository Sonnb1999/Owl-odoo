This module provides sample REST services based on base_rest. The documentation
of provided services is available at the ``/api-docs`` URL. This frontend based
on `Swagger <https://swagger.io/>`_ is generated from the implemented
webservices.
