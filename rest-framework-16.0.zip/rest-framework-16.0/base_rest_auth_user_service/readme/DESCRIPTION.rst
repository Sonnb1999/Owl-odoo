This module adds API endpoints to deal with session authentication and logout.
