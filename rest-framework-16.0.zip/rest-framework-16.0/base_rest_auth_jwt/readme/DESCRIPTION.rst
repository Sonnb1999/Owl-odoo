
This technical addon extend `base_rest` to add the support for auth_jwt
authentication mechanism into the generated openapi documentation.
