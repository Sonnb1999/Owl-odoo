The `roadmap <https://github.com/OCA/odoo-addon-extendable/issues?q=is%3Aopen+is%3Aissue+label%3Aenhancement+label%3Aextendable>`_
and `known issues <https://github.com/OCA/odoo-addon-extendable/issues?q=is%3Aopen+is%3Aissue+label%3Abug+label%3Aextendable>`_ can
be found on GitHub.
