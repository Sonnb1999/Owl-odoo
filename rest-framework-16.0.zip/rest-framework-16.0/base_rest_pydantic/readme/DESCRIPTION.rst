This addon allows you to use Pydantic objects as params and/or response with your
REST API methods.
