Technical module that provides a base handler
for adding and removing controller routes on the fly.

Can be used as a mixin or as a tool.
