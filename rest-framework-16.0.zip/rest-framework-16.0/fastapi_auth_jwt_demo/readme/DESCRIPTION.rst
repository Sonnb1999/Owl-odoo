Tests and demo routes for ``fastapi_auth_jwt``.

The tests and routes are almost identical to those in ``auth_jwt_demo``, and
the JWT validators used are those from ``auth_jwt_demo``.
