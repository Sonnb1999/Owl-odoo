This module can be used in different ways:

* as an example: copy the code and hack your way;
* to test ``graphql_base`` (install it with ``--test-enable``);
* on runbot, login and change the url to ``/graphiql/demo``.
