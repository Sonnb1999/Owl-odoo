This module takes advantage of the concepts introduced in the `datamodel` module to offer mechanisms similar to
(a subset of) the `ModelSerializer` in Django REST Framework. That is, use the definition of the Odoo model to
partially automate the definition of a corresponding `Datamodel` class.
