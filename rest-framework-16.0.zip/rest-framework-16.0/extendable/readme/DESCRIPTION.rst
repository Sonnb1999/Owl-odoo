This addon allows you to use the  `Extendable library`_ within Odoo.

.. _Extendable library: : <https://pypi.org/project/extendable/>
