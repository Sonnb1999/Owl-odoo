from .fastapi_endpoint import FastapiEndpoint
from . import fastapi_endpoint_demo
from . import ir_rule
from . import res_lang
