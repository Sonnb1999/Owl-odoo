By default, all extendable classes defined into your odoo addons are automatically
loaded by the current addon according to the dependency graph computed by Odoo.
