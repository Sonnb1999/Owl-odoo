This addon allows you to use DataModel objects as params and/or response with your
REST API methods.
