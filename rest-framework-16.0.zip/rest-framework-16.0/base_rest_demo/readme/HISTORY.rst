12.0.2.0.0
~~~~~~~~~~

* Licence changed from AGPL-3 to LGPL-3

12.0.1.0.0
~~~~~~~~~~

First official version.
