This addon allows you to define simple data models supporting serialization/deserialization
to/from json

Datamodels are `Marshmallow models <https://github.com/sv-tools/marshmallow-objects>`_ classes that can be inherited as Odoo
Models.
