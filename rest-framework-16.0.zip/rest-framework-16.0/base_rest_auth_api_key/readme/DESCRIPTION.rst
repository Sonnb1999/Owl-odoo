
This technical addon extend `base_rest` to add the support for auth_api_key
authentication mechanism into the generated openapi documentation.
