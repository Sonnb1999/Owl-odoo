This module provides ``FastAPI`` ``Depends`` to allow authentication with `auth_jwt
<https://github.com/OCA/server-auth/tree/16.0/auth_jwt>`_.
